﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Http.Description;
using MarkettingAssistant;
using MarkettingAssistant.Models;

namespace MarkettingAssistant.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]

    public class MarketersController : ApiController
    {
        private MarkettingDBContext db = new MarkettingDBContext();

        // GET: api/Marketers
        public IQueryable<Marketer> GetMarketers()
        {
            return db.Marketers;
        }

        // GET: api/Marketers/5
        [ResponseType(typeof(Marketer))]
        public IHttpActionResult GetMarketer(int id)
        {
            Marketer marketer = db.Marketers.Find(id);
            if (marketer == null)
            {
                return NotFound();
            }

            return Ok(marketer);
        }

        // PUT: api/Marketers/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutMarketer(int id, Marketer marketer)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != marketer.Id)
            {
                return BadRequest();
            }

            db.Entry(marketer).State = System.Data.Entity.EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MarketerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Marketers
        [ResponseType(typeof(Marketer))]
        public IHttpActionResult PostMarketer(Marketer marketer)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Marketers.Add(marketer);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = marketer.Id }, marketer);
        }

        // DELETE: api/Marketers/5
        [ResponseType(typeof(Marketer))]
        public IHttpActionResult DeleteMarketer(int id)
        {
            Marketer marketer = db.Marketers.Find(id);
            if (marketer == null)
            {
                return NotFound();
            }

            db.Marketers.Remove(marketer);
            db.SaveChanges();

            return Ok(marketer);
        }


        #region "MarketerAssignment"

        // POST: api/AddAnalystToTitle
        [ResponseType(typeof(MarketerAssignment))]
        public IHttpActionResult AddAnalystToTitle  (MarketerAssignment marketerAssignment)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.MarketerAssignments.Add(marketerAssignment);
            db.SaveChanges();

           

            return CreatedAtRoute("DefaultApi", new { id = marketerAssignment.Id }, marketerAssignment);
        }


        // POST: api/RemoveAalystFromTitle
        [ResponseType(typeof(MarketerAssignment))]
        public IHttpActionResult RemoveAalystFromTitle(int MarketerID,int BookId)
        {
            MarketerAssignment marketerAssignment = db.MarketerAssignments.Find(MarketerID, BookId);
            if (marketerAssignment == null)
            {
                return NotFound();
            }

            db.MarketerAssignments.Remove(marketerAssignment);
            db.SaveChanges();

            return Ok(marketerAssignment);
        }

        #endregion

        #region  "MarketMaterial"

        // POST: api/AddMarketMaterial
        [ResponseType(typeof(MarketMaterial))]
        public IHttpActionResult AddMarketMaterial(MarketMaterial marketMaterial)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.MarketMaterials.Add(marketMaterial);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = marketMaterial.Id }, marketMaterial);
        }


        // DELETE: api/MarketMaterial/5
        [ResponseType(typeof(MarketMaterial))]
        public IHttpActionResult DeleteMarketMaterial(int id)
        {
            MarketMaterial marketMaterial = db.MarketMaterials.Find(id);
            if (marketMaterial == null)
            {
                return NotFound();
            }

            db.MarketMaterials.Remove(marketMaterial);
            db.SaveChanges();

            return Ok(marketMaterial);
        }

        #endregion


        #region "MarketMaterialAssignment"
        // POST: api/AddMarketMaterialAssignment
        [ResponseType(typeof(MarketMaterialAssignment))]
        public IHttpActionResult AddMarketMaterialAssignment(MarketMaterialAssignment marketMaterialAssignment)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.MarketMaterialAssignments.Add(marketMaterialAssignment);
            db.SaveChanges();

       
            return CreatedAtRoute("DefaultApi", new { id = marketMaterialAssignment.Id }, marketMaterialAssignment);
        }


        // POST: api/RemoveAalystFromTitle
        [ResponseType(typeof(MarketMaterialAssignment))]
        public IHttpActionResult RemoveMarketMaterialFromTitle(int marketMaterialAssignmentId)
        {
            MarketMaterialAssignment marketMaterialAssignment = db.MarketMaterialAssignments.Find(marketMaterialAssignmentId);
            if (marketMaterialAssignment == null)
            {
                return NotFound();
            }

            db.MarketMaterialAssignments.Remove(marketMaterialAssignment);
            db.SaveChanges();

            return Ok(marketMaterialAssignment);
        }

        #endregion



        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool MarketerExists(int id)
        {
            return db.Marketers.Count(e => e.Id == id) > 0;
        }
    }
}