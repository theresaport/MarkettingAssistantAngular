﻿namespace MarkettingAssistant.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using MarkettingAssistant.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<MarkettingAssistant.MarkettingDBContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
            ContextKey = "MarkettingAssistant.MarkettingDBContext";
        }

        protected override void Seed(MarkettingAssistant.MarkettingDBContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method
            //  to avoid creating duplicate seed data.



            context.Books.AddOrUpdate(x => x.Id,
                new Book() { Id = 1, Title = "Tale of two cities" , ISBN ="123-333-44424", AuthorFirstName="Tom", AuthorLastName="Hanks", PublishDate= new DateTime(2021,12,01) },
                new Book() { Id = 2, Title = "Tale of two cities2", ISBN = "123-333-44424", AuthorFirstName = "Tom", AuthorLastName = "Hanks", PublishDate = new DateTime(2021, 12, 01) },
                new Book() { Id = 3, Title = "Tale of two cities3", ISBN = "123-333-44424", AuthorFirstName = "Tom", AuthorLastName = "Hanks", PublishDate = new DateTime(2021, 12, 01) }
        );

        }
    }
}
