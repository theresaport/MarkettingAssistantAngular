export interface Book {
  Id: number;
  Title: string;
  ISBN: string;
  AuthorFirstName: string;
  AuthorLastName: string;
  PublishDate: string;
}
