import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { Book } from './../models/book.model';
import { ColDef } from 'ag-grid-community';
import { CreateTitleComponent } from '../create-title/create-title.component';

@Component({
  selector: 'app-title-list',
  templateUrl: './title-list.component.html',
  styleUrls: ['./title-list.component.css'],
})
export class TitleListComponent implements OnInit {
  title = 'Title List';
  router: any;

  constructor(private bookService: BookService) {}

  columnDefs: ColDef[] = [
    { field: 'Id', hide: true },
    { field: 'Title', sortable: true, filter: true },
    { field: 'ISBN', sortable: true, filter: true },
    { field: 'AuthorFirstName', sortable: true, filter: true },
    { field: 'AuthorLastName', sortable: true, filter: true },
    { field: 'PublishDate', sortable: true, filter: true },
  ];
  rowData: Book[] = []; // my list

  ngOnInit() {
    this.bookService.getBooks().subscribe(
      (response) => {
        this.rowData = response;
      },
      (error) => {
        console.log(error);
      }
    );
  }

  gotoCreateTitle(event: any) {
    this.router.navigate([`${CreateTitleComponent}`]);
  }
}
